import React from 'react';

class CreateEvent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {

    };
  }

  render() {
    return (
      <div>
        <h1>CreateEvent</h1>
      </div>
    );
  }
}

export default CreateEvent;
