const events = [
  {
    category: "Table-Top",
    title: 'Pokemon Team-Up Pre-release',
    description: 'Something about how fun it will be and how much it costs here',
    private: false,
    time: "Mon Feb 18 2019 16:25:18 GMT-0600 (Central Standard Time)",
    lat: 30.000002,
    long: -90.000001,
  },
  {
    category: "Outdoors",
    title: 'Pokemon Go Community Day',
    description: 'EXAMPLE',
    private: false,
    time: "Mon Feb 18 2020 12:33:54 GMT-0600 (Central Standard Time)",
    lat: 29.9483937,
    long: -90.1312464,
  },
  {
    category: 'Table-Top',
    title: 'Dungeons and dragons',
    description: 'EXAMPLE2',
    private: false,
    time: "Mon Feb 18 2020 12:33:54 GMT-0600 (Central Standard Time)",
    lat: 30.0044912,
    long: -90.1794587,
  },
];
export default events;
