import React from 'react';

const Categories = () => (
  <h2>Categories</h2>
);
export default Categories;
