module.exports = {
    "extends": "airbnb",
    rules: {
        "no-console": "off"
    }
};